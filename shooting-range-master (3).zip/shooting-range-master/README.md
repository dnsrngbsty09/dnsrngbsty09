# shooting-range

HTML canvas game

[Play](https://taras-d.github.io/shooting-range)

## Installation notes
1. `npm install` - install Node modules
2. `npm run compile` - compile typescript
3. Open `index.html` in the browser
